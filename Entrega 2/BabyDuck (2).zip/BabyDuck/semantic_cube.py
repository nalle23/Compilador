cubo_semantico = {
    # Operadores Aritméticos
    '+': {
        'int':   {'int': 'int',   'float': 'float'},
        'float': {'int': 'float', 'float': 'float'}
    },
    '-': {
        'int':   {'int': 'int',   'float': 'float'},
        'float': {'int': 'float', 'float': 'float'}
    },
    '*': {
        'int':   {'int': 'int',   'float': 'float'},
        'float': {'int': 'float', 'float': 'float'}
    },
    '/': {
        # La división siempre produce float para evitar pérdida de precisión
        'int':   {'int': 'float', 'float': 'float'},
        'float': {'int': 'float', 'float': 'float'}
    },

    # Operadores Relacionales (Producen 'bool')
    '>': {
        'int':   {'int': 'bool',  'float': 'bool'},
        'float': {'int': 'bool',  'float': 'bool'}
    },
    '<': {
        'int':   {'int': 'bool',  'float': 'bool'},
        'float': {'int': 'bool',  'float': 'bool'}
    },
    '==': {
        'int':   {'int': 'bool',  'float': 'bool'},
        'float': {'int': 'bool',  'float': 'bool'},
        'string': {'string': 'bool'}
    },
    '!=': {
        'int':   {'int': 'bool',  'float': 'bool'},
        'float': {'int': 'bool',  'float': 'bool'},
        'string': {'string': 'bool'}
    },

    '=': {

        'int':   {'int': 'int'},
        'float': {'float': 'float'}
    }

}
