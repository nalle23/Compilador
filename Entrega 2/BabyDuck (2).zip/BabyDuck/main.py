import scanner
import ply.yacc as yacc
import parser as babyduck_parser


# Diccionario de funciones (estructura semántica)
function_directory = {}
current_function = 'global'


def initialize_semantic_structures():
    """Reinicia las estructuras semánticas para una nueva compilación."""
    global function_directory, current_function
    function_directory.clear()
    function_directory['global'] = {'type': 'program_scope', 'vars': {}}
    current_function = 'global'

def run_compiler(code_input):
    """Ejecuta el escáner y el parser sobre el código fuente dado."""
    initialize_semantic_structures()
    scanner.lexer.lineno = 1
    scanner.lexer.input("")

    print("--- Scanner Output ---")
    scanner.lexer.input(code_input)

    tokens_list = []
    while True:
        tok = scanner.lexer.token()
        if not tok:
            break
        print(f"[{tok.type}] -> {repr(tok.value)} (línea {tok.lineno})")
        tokens_list.append(tok)

    if not tokens_list:
        print("(No se generaron tokens)")

    print("\n--- Parser Output ---")
    try:
        parser = yacc.yacc(module=babyduck_parser, debug=False, write_tables=False)
        result = parser.parse(input=code_input, lexer=scanner.lexer)
        if result is not None:
            print("Resultado del Parseo (AST simplificado):")
            print(result)
        else:
            print("El parseo no produjo resultado (posible error de sintaxis).")
        return result
    except Exception as e:
        print(f"EXCEPCIÓN DURANTE EL PARSEO: {e}")
        return None

def run_test_cases():  #Todos los casos funcionan si se corren individualmente (necesito corregir eso)
    test_cases = [
        # Caso 1: Código correcto
        """program miPrograma;
        var x : int; y : float;
        main { x = 10; y = 20.5; if (x > 0) { y = y + 1.0; } }
        end""",

        # Caso 2: Error Léxico
        """program errorLexico;
        var x : int;
        main { x = 10 @; }
        end""",

        # Caso 3: Error Sintáctico (falta ';')
        """program errorSintactico;
        var x : int;
        main { x = 10 }
        end""",

        # Caso 4: Expresión matemática correcta
        """program expresionCorrecta;
        var resultado : int;
        main { resultado = (5 + 3) * (2 - 1); }
        end""",

        # Caso 5: Llave faltante
        """program errorFaltaLlave;
        var y : int;
        main { y = 25;
        end""",

        # Caso 6: Declaraciones múltiples
        """program multiDeclaraciones;
        var a : int; b : int; c : int; d : float;
        main { a = 1; b = 2; c = a + b; d = c * 1.5; }
        end""",

        # Caso 7: Número mal formado
        """program numeroMalFormado;
        var num : float;
        main { num = 10..5; }
        end""",

        # Caso 8: Error Semántico - variable no declarada
        """program errorSemantico;
        var x : int;
        main { x = 10; y = x + 5; }
        end""",

    ]

    for i, code in enumerate(test_cases):
        print(f"\n======= CASO DE PRUEBA {i + 1} =======")
        print("--- Código Fuente ---")
        print(code)
        print("----------------------")
        try:
            run_compiler(code)
        except Exception as e:
            print(f" Error durante el caso {i + 1}: {e}")
        print(f"======= FIN CASO {i + 1} =======")

    

if __name__ == "__main__":
    run_test_cases()
