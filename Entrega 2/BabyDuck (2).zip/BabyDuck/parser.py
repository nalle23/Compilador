import ply.yacc as yacc
from scanner import tokens 
from semantic_cube import cubo_semantico


def initialize_semantic_structures():
    global function_directory, current_function

    function_directory = {}
    function_directory['global'] = { 
        'type': 'program_scope', 
        'vars': {}
    }
    
    current_function = 'global'
    print("Estado de function_directory:", function_directory)  # 


function_directory = {}
current_function = 'global'
print("Estado de function_directory:", function_directory)  # Aquí está vacío


# --- Definición de Precedencia de Operadores ---
# Menor precedencia a mayor precedencia
precedence = (
    ('left', 'REL_OP'),          # Nivel más bajo: ==, !=, <, >
    ('left', 'PLUS', 'MINUS'),   # Nivel medio: +, -
    ('left', 'MULTIPLY', 'DIVIDE'), # Nivel más alto: *, /
)

#---Semantica----
def add_function(name, return_type):
    if name in function_directory:
        raise Exception(f"Función '{name}' ya declarada.")
    function_directory[name] = {
        'type': return_type,
        'vars': {}
    }

def add_variable(func_name, var_name, var_type):
    # Asegurar que el ámbito 'global' existe
    if func_name == 'global' and 'global' not in function_directory:
        initialize_semantic_structures()  

    if var_name in function_directory[func_name]['vars']:
        raise Exception(f"Variable '{var_name}' ya declarada en función '{func_name}'")
    
    function_directory[func_name]['vars'][var_name] = {
        'type': var_type,
        'scope': 'local' if func_name != 'global' else 'global'
    }


def lookup_variable(func_name, var_name):
    # Primero se revisa el ámbito local
    if func_name in function_directory and var_name in function_directory[func_name]['vars']:
        return function_directory[func_name]['vars'][var_name]['type']
    
    # Si no está en el local, revisa en 'global'
    elif 'global' in function_directory and var_name in function_directory['global']['vars']:
        return function_directory['global']['vars'][var_name]['type']
    
    # Si no existe en ningún ámbito, lanza error
    else:
        raise Exception(f"Variable '{var_name}' no declarada en función '{func_name}' ni en 'global'")

    
def get_constant_type(value):
     if isinstance(value, int): return 'int'
     if isinstance(value, float): return 'float'
     if isinstance(value, str): return 'string' 
     return 'unknown'

def get_node_type(node):
    """
    Extrae el tipo de dato de un nodo del AST.
    Asume que los nodos tienen una estructura que incluye el tipo.
    """
    if not isinstance(node, tuple):
        # Si el nodo es solo un valor simple (ej. un número directo, aunque no debería pasar
        # si p_factor/p_constante se ajustan), intenta inferir o devuelve error/unknown.
        # O podría ser el caso de un ID antes de buscar su tipo (no ideal).
        # Mejor asegurarse que todos los nodos relevantes sean tuplas estructuradas.
        if isinstance(node, (int, float)):
             return get_constant_type(node) 
        # Si es un string (nombre de ID no resuelto), no podemos saber el tipo aún.
        # Esto indica un problema en cómo se construyó el AST o cuándo se llama a get_node_type.
        # print(f"Advertencia: Nodo no es tupla estructurada: {node}")
        return 'unknown' # O lanzar un error

    node_kind = node[0]

    if node_kind in ('+', '-', '*', '/', '==', '!=', '<', '>'): # Operación Binaria
        # Se asume que el tipo resultante está en la posición 4 
        if len(node) >= 4:
            return node[3]
        else:
            # Esto indicaría que el nodo de operación binaria no se construyó correctamente
            # en p_exp, p_termino, p_expresion para incluir el tipo.
            raise ValueError(f"Nodo de operación binaria '{node_kind}' no contiene tipo resultante: {node}")

    elif node_kind == 'id': # Identificador ('id', name, type)
        if len(node) >= 3:
            return node[2]
        else:
            raise ValueError(f"Nodo identificador no contiene tipo: {node}")

    elif node_kind == 'const': # Constante ('const', value, type)
         if len(node) >= 3:
            return node[2]
         else:
             try:
                 return get_constant_type(node[1])
             except IndexError:
                 raise ValueError(f"Nodo constante malformado: {node}")
    else:
        print(f"Advertencia/Error: Tipo de nodo desconocido o no aplicable para get_node_type: {node_kind} en {node}")
        return 'unknown_structure' # O None, o lanzar error


def check_semantic(operator, type1, type2):
    """
    Se realiza la verificación semántica de una operación (binaria o asignación)
    usando el cubo semántico global 'cubo_semantico'.
    Args:
        operator: El operador (ej. '+', '-', '*', '/', '==', '<', '=', etc.).
        type1: El tipo del primer operando.
        type2: El tipo del segundo operando.
    Returns:
        El tipo resultante de la operación según el cubo semántico.
    Raises:
        TypeError: Si la operación no es válida para los tipos dados según el cubo.
        ValueError: Si el operador no está definido en el cubo.
    """
    # aseguro de que los tipos no sean 'unknown' si es posible
    if type1 == 'unknown' or type2 == 'unknown':
         raise TypeError(f"Error Semántico: Tipos desconocidos '{type1}', '{type2}' para la operación '{operator}'.")

    # Verificar si el operador existe en el cubo
    if operator not in cubo_semantico:
        raise ValueError(f"Operador '{operator}' no definido en el cubo semántico.")

    op_table = cubo_semantico[operator]

    # Verificar si type1 existe para este operador
    if type1 not in op_table:
         raise TypeError(f"Error Semántico: Operación '{operator}' no válida para el primer tipo '{type1}'.")

    # Verificar si type2 existe para la combinación (operator, type1)
    if type2 not in op_table[type1]:
         raise TypeError(f"Error Semántico: Operación '{operator}' no definida para la combinación de tipos '{type1}' y '{type2}'.")

    # Obtener el tipo resultante
    result_type = op_table[type1][type2]

    # Si el cubo indica un error (ej. con None, 'error', etc.)
    if result_type is None or result_type == 'error': # Ajusta 'error' si tu cubo usa otra cosa
        raise TypeError(f"Error Semántico: Operación no permitida '{operator}' entre '{type1}' y '{type2}'.")

    return result_type

# --- Reglas del Parser ---
# Estructura general del programa
def p_program(p):
   '''program : PROGRAM IDENTIFIER SEMICOLON vars_opt funcs_opt mark_main MAIN body END'''
   # ...
   p[0] = ("program", p[2], p[4], p[5], p[8]) # Ajustar índice por mark_main

def p_mark_main(p):
    '''mark_main : empty'''
    global current_function
    add_function('main', 'void') 
    current_function = 'main'


# Secciones opcionales
def p_vars_opt(p):
    '''vars_opt : vars
                | empty'''
    p[0] = p[1]

def p_funcs_opt(p):
    '''funcs_opt : funcs
                 | empty'''
    p[0] = p[1]

# Declaración de variables
def p_vars(p):
    '''vars : VAR var_declaration_list'''
    p[0] = ("vars", p[2])

def p_var_declaration_list(p):
    '''var_declaration_list : IDENTIFIER COLON type SEMICOLON var_declaration_list
                             | IDENTIFIER COLON type SEMICOLON'''
    var_name = p[1]
    var_type = p[3]
    # >> PUNTO NEURÁLGICO <<
    add_variable(current_function, var_name, var_type) # valida duplicados
    # Resto del código para construir la lista...
    if len(p) == 6:
         p[0] = [(var_name, var_type)] + p[5]
    else:
         p[0] = [(var_name, var_type)]


# Tipos de datos
def p_type(p):
    '''type : INT
            | FLOAT'''
    p[0] = p[1] # Solo retorna 'int' o 'float'

# Funciones (placeholder por ahora)
def p_funcs(p):
    '''funcs : empty''' # Expandir luego...
    p[0] = ("funcs", [])

# Cuerpo principal o de función
def p_body(p):
    '''body : LBRACE statement_list RBRACE'''
    p[0] = ("body", p[2])

# Lista de statements (puede estar vacía)
def p_statement_list(p):
    '''statement_list : statement statement_list
                      | empty'''
    if len(p) == 3:
        p[0] = [p[1]] + p[2] # Agrega el statement actual a la lista recursiva
    else:
        p[0] = [] # Lista vacía

# Tipos de statements (expandir con IF, WHILE, etc.)
def p_statement(p):
    '''statement : assign
                 | print_stmt
                 | if_stmt'''
              # | condition
             # | cycle
            # | f_call '''
    p[0] = p[1]

def p_if_stmt(p):
   '''if_stmt : IF LPAREN expresion RPAREN body''' # Falta ELSE opcional
   condition_node = p[3]
   body_node = p[5]

   condition_type = get_node_type(condition_node)

   if condition_type != 'bool':
       # Si la expresión no es relacional, get_node_type devolverá int/float/etc.
       # Si es relacional, debería devolver 'bool' 
       print(f"Error Semántico: La condición del IF debe ser booleana, se obtuvo '{condition_type}' en línea {p.lineno(1)}")
       raise TypeError("Condición de IF no booleana")

   p[0] = ('if', condition_node, body_node) # Falta manejar el ELSE

# Asignación
def p_assign(p):
    '''assign : IDENTIFIER ASSIGN expresion SEMICOLON'''
    var_name = p[1]
    expression_node = p[3]

    try:
        var_type = lookup_variable(current_function, var_name)
    except Exception as e:
         print(f"Error Semántico: {e} en línea {p.lineno(1)}")
         raise e
    # Necesita obtener el tipo resultante de la expresión
    expr_type = get_node_type(expression_node) # Usando la función auxiliar
    
    try:
        # No se necesita el tipo resultante de '=', solo validar compatibilidad
        check_semantic('=', var_type, expr_type)
        p[0] = ("assign", var_name, expression_node) # AST
    except TypeError as e:
         print(f"Error Semántico: {e} en línea {p.lineno(2)}") # Línea del '='
         raise e

# Escritura (Print)
def p_print_stmt(p):
    '''print_stmt : PRINT LPAREN expresion RPAREN SEMICOLON'''
    p[0] = ("print", p[3])

# --- GRAMÁTICA DE EXPRESIONES (Basada en tu PDF y usando precedencia) ---
def p_expresion(p):
    '''expresion : exp REL_OP exp
                 | exp'''
    if len(p) == 4:
        op = p[2]
        left_node = p[1]
        right_node = p[3]
        
        left_type = get_node_type(left_node)
        right_type = get_node_type(right_node)

        try:
            result_type = check_semantic(op, left_type, right_type)
            p[0] = (op, left_node, right_node, result_type)  # Ahora incluye el tipo resultante
        except TypeError as e:
            print(f"Error Semántico: {e} en línea {p.lineno(2)}")
            raise e
    else:
        p[0] = p[1]


def p_exp(p):
    '''exp : exp PLUS termino
           | exp MINUS termino
           | termino'''
    if len(p) == 4:
        op = p[2]
        left_node = p[1]
        right_node = p[3]
        # Se asume que p[1] y p[3] ahora devuelven (tipo, valor_o_AST)
        # Simplificando, si p[1] devuelve ('id', name, type) o ('const', val, type) o (op, left, right, type)
        left_type = get_node_type(left_node) # Se necesita una función para extraer el tipo
        right_type = get_node_type(right_node)

        try:
            result_type = check_semantic(op, left_type, right_type)
            # Crear el nodo del AST con el tipo resultante
            p[0] = (op, left_node, right_node, result_type)
        except TypeError as e:
            print(f"Error Semántico: {e} en línea {p.lineno(2)}") # línea del operador
            raise e # O manejar el error
    else: 
        p[0] = p[1] # Propagar el nodo/tipo del termino

def p_termino(p):
    '''termino : termino MULTIPLY factor
               | termino DIVIDE factor
               | factor'''
    if len(p) == 4:
        p[0] = (p[2], p[1], p[3]) # Operador, Izquierda, Derecha
    else:
        p[0] = p[1]

def p_factor(p):
    '''factor : LPAREN expresion RPAREN
              | PLUS constante
              | MINUS constante
              | constante
              | IDENTIFIER'''
    if len(p) == 2 and isinstance(p[1], str): #IDENTIFIER
        var_name = p[1]
        try:
            var_type = lookup_variable(current_function, var_name)
            # Guardar el tipo para usarlo en check_semantic más arriba
            p[0] = ('id', var_name, var_type) # Devolver tipo junto al ID
        except Exception as e:
            print(f"Error Semántico: {e} en línea {p.lineno(1)}")
            # Manejar el error
    elif len(p) == 4: # Paréntesis
        p[0] = p[2] # Propagar resultado de la expresion interna
    elif len(p) == 3: # Signo opcional
        # Obtener el tipo de la constante p[2]
        const_type = get_constant_type(p[2][1]) # Asume una función auxiliar
        # Validar si +/- se aplica a ese tipo aquí o en el cubo
        p[0] = (p[1], p[2], const_type) # Operador unario, constante, tipo
    else: # Constante sola
         # Obtener el tipo de la constante p[1]
        const_type = get_constant_type(p[1][1]) # Asume una función auxiliar
        p[0] = (p[1][0], p[1][1], const_type) # 'const', valor, tipo

def p_constante(p):
    '''constante : CTE_INT
                 | CTE_FLOAT
                 | CTE_STRING'''
    p[0] = ('const', p[1]) # Marcar como constante con su valor

def p_empty(p):
    'empty :'
    pass


# Manejo de errores de sintaxis
def p_error(p):
    if p:
        print(f"ERROR DE SINTAXIS: Token inesperado '{p.value}' (Tipo: {p.type}) en línea {p.lineno}")
    else:
        print("ERROR DE SINTAXIS: Fin inesperado del archivo (EOF)")
    
    raise SyntaxError("Deteniendo análisis por error sintáctico")  



# Construcción del parser
parser = yacc.yacc()